---
layout: post
tags: []
categories: []
date: 2024-11-17
#excerpt: ''
#image: 'BASEURL/assets/blog/img/.png'
#description:
#permalink:
title: 'title'
---


Mike Johnson
- May 16
Andy Biggs of Arizona
Lauren Boebert of Colorado
Eric Burlison of Missouri
Michael Cloud of Texas
Andrew Clyde of Georgia
Eli Crane of Arizona
Byron Donalds of Florida
Matt Gaetz of Florida
Bob Good of Virginia
Diana Harshbarger of Tennessee
Ronny Jackson of Texas
Anna Paulina Luna of Florida
Mary Miller of Illinois
Cory Mills of Florida
Nicole Malliotakis of New York
Dan Meuser of Pennsylvania
Troy Nehls of Texas
Ralph Norman of South Carolina
Andy Ogles of Tennessee
Maria Elvira Salazar of Florida
Keith Self of Texas
Dale Strong of Alabama
Mike Waltz of Florida
Daniel Webster of Florida