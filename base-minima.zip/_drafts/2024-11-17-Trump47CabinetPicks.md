---
layout: post
tags: [Donald Trump, Kristi Noem, Lee Zeldin, Elise Stefanik, Matt Gaetz,  Colin Jost, Michael Che, Weekend Update, Saturday Night Live, politics, video, cabinet picks]
categories: [2024 post election]
date: 2024-11-17 1:49 PM
excerpt: "“Trump nominated Kristi Noem to lead the Department of Homeland Security, Lee Zeldin to head the EPA and Elise Stefanik as ambassador to the U.N. and then someone yelled, ‘Now do a silly one. And Gaetz said the same thing he does when he sees a teenage girl, ‘I’ll do it,’”"
#image: 'BASEURL/assets/blog/img/.png'
#description:
#permalink:
title: "Trump’s Cabinet Picks"
---



## Trump’s Cabinet Choices – Weekend Update

<iframe width="560" height="315" src="https://www.youtube.com/embed/V2Oe1j1DPiI?si=TI80Y5qbTq-HEJSI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

″[He] became the first brain worm survivor nominated to a cabinet-level position,” quipped Jost in a reference to the conspiracy theorist claiming that a parasite once “ate a portion” of his brain.

Jost admitted that the former independent presidential candidate “doesn’t have a lot of experience.”

Jost, alongside his “Weekend Update” co-host Michael Che, roasted Trump’s controversial cabinet picks at the top of the “SNL” news segment.

He joked that Trump continued to announce “everyone he’s going to fire” in six months.

“Trump nominated Kristi Noem to lead the Department of Homeland Security, Lee Zeldin to head the EPA and Elise Stefanik as ambassador to the U.N. and then someone yelled, ‘Now do a silly one,’” said Jost as a picture of former Rep. Matt Gaetz (R-Fla.) appeared on the screen.

Trump nominated Gaetz, who has faced allegations of sexual misconduct, to be his attorney general on Wednesday. The pick has sparked bipartisan backlash.

“And Gaetz said the same thing he does when he sees a teenage girl, ‘I’ll do it,’” quipped Jost of Gaetz, who has denied the allegations and did not face charges after the Justice Department dropped a sex trafficking investigation into him.

